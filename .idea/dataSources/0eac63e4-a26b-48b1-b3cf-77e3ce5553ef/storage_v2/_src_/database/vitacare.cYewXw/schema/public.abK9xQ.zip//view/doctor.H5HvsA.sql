create view doctor (id, specialty, "licenseNumber", bio, "clinicName", address, "organizationId") as
SELECT "Doctor".id,
       "Doctor".specialty,
       "Doctor"."licenseNumber",
       "Doctor".bio,
       "Doctor"."clinicName",
       "Doctor".address,
       "Doctor"."organizationId"
FROM "Doctor";

alter table doctor
    owner to wilmervasquez;

